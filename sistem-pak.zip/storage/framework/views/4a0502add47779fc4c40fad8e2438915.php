<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Sistem Keuangan Persatuan Amal Kematian'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset("img/favicon.ico")); ?>">

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Geist:wght@100..900&display=swap" rel="stylesheet">

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="<?php echo e(asset("js/main.js")); ?>"></script>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
      </script>
</body>


</html>
<?php /**PATH /home/hiddev/Jobs/keuangan-pak/resources/views/layouts/main.blade.php ENDPATH**/ ?>