<?php $__env->startSection('title', 'Login | Sistem Keuangan Persatuan Amal Kematian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-full h-svh flex justify-between items-center">
        <div class="px-9 md:px-0 w-full md:w-2/5 h-full bg-white flex items-center justify-center">
            <div class="w-full md:w-2/3">
                <div class="flex items-center gap-2 mb-9">
                    <img src="<?php echo e(asset('img/logo.svg')); ?>" alt="Logo" class="w-9 h-9">
                    <div class="leading-tight">
                        <div class="text-sm font-semibold">Sistem Keuangan</div>
                        <div class="text-sm text-gray-600">Persatuan Amal Kematian</div>
                    </div>
                </div>
                <h1 class="text-3xl font-bold">Sign In</h1>

                <?php if($errors->any()): ?>
                    <div class="mt-4 rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                        <p class="font-semibold">Login gagal:</p>
                        <ul class="mt-1 list-disc pl-5">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route("login")); ?>" method="post" class="mt-4 flex flex-col gap-3">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="username" class="text-gray-600 text-sm">NIK / Username</label>
                        <input type="text" id="username" name="username" value="<?php echo e(old('username')); ?>"
                            class="p-3 text-sm w-full border border-gray-300 rounded-md <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            autofocus>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="password" class="text-gray-600 text-sm">Password</label>
                        <div class="relative w-full max-w-sm">
                            <input type="password" id="password" name="password" placeholder="******"
                                class="p-3 text-sm w-full border border-gray-300 rounded-md <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <button type="button" onclick="togglePassword()"
                                class="absolute inset-y-0 right-3 flex items-center text-gray-500 hover:text-gray-700">
                                👁
                            </button>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <button
                            class="bg-green-800 mt-2 p-3 text-sm w-full rounded-md text-white font-semibold transition-all duration-200 ease-in-out hover:bg-green-700 active:py-2">Sign
                            In</button>
                    </div>
                </form>
                <p class="text-center mt-4 text-gray-600 text-sm">Sistem Keuangan PAK ©2025</p>
            </div>
        </div>
        <div class="w-3/5 h-screen bg-gradient-to-t from-green-800 to-green-500 hidden md:flex justify-center items-center">
            <div class="flex items-center gap-5 opacity-75">
                <img src="<?php echo e(asset("img/logo-icon.svg")); ?>" alt="Logo">
                <div class="flex flex-col">
                    <p class="leading-7 text-3xl text-white">Sistem Keuangan <br> <span class="font-semibold">Persatuan Amal
                            Kematian</span></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/hiddev/Jobs/keuangan-pak/resources/views/auth/login.blade.php ENDPATH**/ ?>