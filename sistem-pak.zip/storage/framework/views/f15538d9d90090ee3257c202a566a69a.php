<?php $__env->startSection('title', 'Dashboard | Sistem Keuangan Persatuan Amal Kematian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-8">
        <h1 class="text-3xl leading-8">
            Halo,<br>
            <span class="font-semibold"><?php echo e(auth()->user()->name ?? 'User'); ?>!</span>
        </h1>
        <p class="text-gray-500 text-sm">Selamat Datang Di Dashboard <?php echo e(ucfirst(auth()->user()->role)); ?></p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <?php
            $date = now();

            $cards = [
                ['title' => 'Saldo', 'subtitle' => 'Per ' . $date->locale('id')->translatedFormat('F Y'), 'value' => rupiah($summary->balance), 'icon' => 'money-bag.svg'],
                ['title' => 'Uang Masuk', 'subtitle' => 'Per ' . $date->locale('id')->translatedFormat('F Y'), 'value' => rupiah($summary->total_income), 'icon' => 'income.svg'],
                ['title' => 'Uang Keluar', 'subtitle' => 'Per ' . $date->locale('id')->translatedFormat('F Y'), 'value' => rupiah($summary->total_expense), 'icon' => 'expanse.svg'],
            ];
        ?>

        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white border border-gray-200 rounded-md p-4 flex items-start justify-between transition-all duration-300 ease-in-out hover:shadow-lg shadow-gray-100">
                <div>
                    <div class="text-sm font-semibold text-gray-900"><?php echo e($card['title']); ?></div>
                    <div class="text-sm text-gray-500"><?php echo e($card['subtitle']); ?></div>
                    <div class="mt-6 text-2xl font-bold"><?php echo e($card['value']); ?></div>
                </div>
                <div class="w-10 h-10 rounded-md bg-green-800 text-white flex items-center justify-center">
                    <img src="<?php echo e(asset("img/icons/" . $card["icon"])); ?>" alt="" class="w-5 h-5">
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="flex gap-4 mt-4">
        <div class="w-2/3 bg-white p-3 border border-gray-300 rounded-md transition-all duration-300 ease-in-out hover:shadow-lg shadow-gray-100">
            <canvas id="chart"></canvas>
        </div>
        <div class="flex flex-col justify-between w-1/3 gap-2 bg-white p-3 border border-gray-300 rounded-md transition-all duration-300 ease-in-out hover:shadow-lg shadow-gray-100">
            <p class="font-semibold text-base">Aktifitas Terkini</p>
            <?php $__currentLoopData = $latest_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-2 border border-gray-200 rounded flex items-center gap-2">
                    <div class="w-3 h-3 <?php echo e($latest_payment->type == "income" ? "bg-green-800" : "bg-red-800"); ?> rounded-full"></div>
                    <div>
                        <p class="text-sm"><?php echo e($latest_payment->type == "income" ? "Uang Masuk" : "Uang Keluar"); ?> - <?php echo e(formatTanggalIndonesia($latest_payment->created_at)); ?></p>
                        <p class="text-sm"><?php echo e(rupiah($latest_payment->amount)); ?> - <?php echo e($latest_payment->description); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const chartData = <?php echo json_encode($data, 15, 512) ?>;
    </script>
    <script>
        const labels = chartData.map(item => item.hari);
        const income = chartData.map(item => item.income);
        const expense = chartData.map(item => item.expense);

        new Chart(document.getElementById('chart'), {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Uang Masuk',
                        data: income,
                        borderColor: '#016630',
                        backgroundColor: '#069147',
                    },
                    {
                        label: 'Uang Keluar',
                        data: expense,
                        borderColor: '#940000',
                        backgroundColor: '#B70909',
                    }
                ]
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/hiddev/Jobs/keuangan-pak/resources/views/admin/index.blade.php ENDPATH**/ ?>