<script src="https://app.sandbox.midtrans.com/snap/snap.js"
    data-client-key="<?php echo e(config('services.midtrans.client_key')); ?>"></script>

<button id="pay-button">Bayar Sekarang</button>

<script>
document.getElementById('pay-button').onclick = function () {
    snap.pay('<?php echo e($snapToken); ?>');
};
</script>
<?php /**PATH /home/hiddev/Jobs/keuangan-pak/resources/views/pay.blade.php ENDPATH**/ ?>