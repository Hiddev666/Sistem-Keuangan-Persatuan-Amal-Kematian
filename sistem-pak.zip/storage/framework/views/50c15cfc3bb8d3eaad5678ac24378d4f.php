<?php $__env->startSection('title', 'Dashboard | Sistem Keuangan Persatuan Amal Kematian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-8 py-4 px-8 flex justify-center items-center">
            <div class="border border-gray-300 p-3 rounded w-full md:w-1/3 flex flex-col gap-2">
                <h1 class="font-semibold text-2xl">Donasi</h1>
                <form action="<?php echo e(route("member_donasi_pay")); ?>" method="post" class="flex flex-col gap-2">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="amount" class="text-gray-600 text-sm">Nominal Donasi</label>
                        <input type="text" id="amount" name="amount"
                            class="p-3 text-sm w-full border border-gray-300 rounded-md"
                            autofocus>
                    </div>
                    <button type="submit" id="pay-button" class="w-full p-2 text-white font-semibold bg-green-800 rounded">Bayar Sekarang</button>
                </form>
            </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/hiddev/Jobs/keuangan-pak/resources/views/member/kas/donation.blade.php ENDPATH**/ ?>